(function($){
$(document).ready(function(){



$('#header .form-submit').attr('value', '');
$('.region-sidebar-second #block-menu-menu-proyectos h2.title').html('Proyectos');

$('#block-menu-menu-mquienessomos h2.title').html('');
$('block-menu-primary-links h2.title').html('');
//$('#block-menu-menu-mquienessomos h2.title').html('');


$('.section-investigadores h1').html('');

$('#block-menu-menu-menuproyectoscuencas h2.title').html('');


});
})(jQuery);


